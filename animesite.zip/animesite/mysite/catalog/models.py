from django.db import models
from django.urls import reverse
import uuid

class AnimeModel(models.Model):
	title = models.CharField(max_length=200) 
	studio = models.ForeignKey('StudioModel', on_delete=models.SET_NULL, null=True)
	summary = models.TextField(max_length=10000, help_text='Краткое содержание книги')
	country = models.CharField('CountryModel', max_length=13, unique=True)
	genre = models.ManyToManyField('GenreModel', help_text='Выберите жанр')

	def __str__(self):
		return self.title

	def get_absolute_url(self):
		return reverse('index')


class GenreModel(models.Model):
	name = models.CharField(max_length=200, help_text='Введите жанр книги')

	def __str__(self):
		return self.name

	def get_absolute_url(self):
		return reverse('index')

class StudioModel(models.Model):
	name = models.CharField(max_length=100)
	class Meta:
		ordering = ['name']

	def get_absolute_url(self):
		return reverse('index')#, args=[str(self.id)])

	def __str__(self):
		return f'{self.name}'