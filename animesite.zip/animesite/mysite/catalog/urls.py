from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('add-anime', views.new_book, name="add-anime"),
    path('book/<int:pk>/renew', views.renew_book_librarian, name='renew-anime-database'),
]